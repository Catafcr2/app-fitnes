package clase;

public class Planes {

    //Declaracion
    private int xtreme;
    private int mindFullness;

    //Constructor
    public Planes()
    {
        xtreme = 12000;
        mindFullness = 24000;
    }

    //Accesadores
    public int getXtreme()
    {
        return xtreme;
    }

    public int getMindFullness()
    {
        return mindFullness;
    }
}
